package com.kindbord.shadowstalker.entity;

import com.kindbord.shadowstalker.ShadowStalkerMod;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class ShadowStalker extends Monster {
    private int watchedTicks = 0;
    private int scareCooldown = 0;

    public ShadowStalker(EntityType<? extends Monster> type, Level level) { super(type, level); this.xpReward = 12; }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 60.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.29D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.8D);
    }

    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, true));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 24.0F));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override public void tick() {
        super.tick();
        if (level().isClientSide || !isAlive()) return;
        if (scareCooldown > 0) scareCooldown--;
        Player watcher = findWatcher();
        if (watcher != null) {
            watchedTicks++;
            getNavigation().stop();
            setTarget(null);
            if (scareCooldown == 0 && watchedTicks == 1) {
                watcher.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 50, 0, false, false, true));
                level().playSound(null, blockPosition(), SoundEvents.ENDERMAN_STARE, getSoundSource(), 1.0F, 0.65F);
                scareCooldown = 100;
            }
            if (watchedTicks >= 40) {
                level().playSound(null, blockPosition(), SoundEvents.ENDERMAN_TELEPORT, getSoundSource(), 1.0F, 0.7F);
                discard();
            }
        } else {
            watchedTicks = 0;
        }
    }

    private Player findWatcher() {
        for (Player player : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(32.0D))) {
            if (!player.isAlive() || player.isSpectator() || !player.hasLineOfSight(this)) continue;
            Vec3 look = player.getViewVector(1.0F).normalize();
            Vec3 toward = position().add(0, getBbHeight() * 0.55D, 0).subtract(player.getEyePosition()).normalize();
            if (look.dot(toward) > 0.94D) return player;
        }
        return null;
    }

    @Override public boolean checkSpawnRules(LevelReader level, net.minecraft.world.entity.MobSpawnType reason) {
        return super.checkSpawnRules(level, reason) && level.getMaxLocalRawBrightness(blockPosition()) <= 7;
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENDERMAN_AMBIENT; }
    @Override protected SoundEvent getHurtSound(net.minecraft.world.damagesource.DamageSource source) { return SoundEvents.ENDERMAN_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENDERMAN_DEATH; }
    @Override protected void playStepSound(BlockPos pos, BlockState state) { playSound(SoundEvents.WARDEN_STEP, 0.65F, 0.55F); }
}
