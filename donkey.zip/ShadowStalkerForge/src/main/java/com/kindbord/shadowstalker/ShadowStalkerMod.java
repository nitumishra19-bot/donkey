package com.kindbord.shadowstalker;

import com.kindbord.shadowstalker.entity.ShadowStalker;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@Mod(ShadowStalkerMod.MODID)
public class ShadowStalkerMod {
    public static final String MODID = "shadowstalker";
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final RegistryObject<EntityType<ShadowStalker>> SHADOW_STALKER = ENTITIES.register("shadow_stalker",
            () -> EntityType.Builder.of(ShadowStalker::new, MobCategory.MONSTER)
                    .sized(0.85F, 2.95F).clientTrackingRange(10).updateInterval(2).build("shadowstalker:shadow_stalker"));

    public ShadowStalkerMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        bus.addListener(this::createAttributes);
    }

    private void createAttributes(EntityAttributeCreationEvent event) {
        event.put(SHADOW_STALKER.get(), ShadowStalker.createAttributes().build());
    }
}
