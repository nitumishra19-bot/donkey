package com.kindbord.shadowstalker.client;

import com.kindbord.shadowstalker.ShadowStalkerMod;
import com.kindbord.shadowstalker.entity.ShadowStalker;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public class ShadowStalkerRenderer extends MobRenderer<ShadowStalker, HumanoidModel<ShadowStalker>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(ShadowStalkerMod.MODID, "textures/entity/shadow_stalker.png");

    public ShadowStalkerRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.45F);
        this.shadowRadius = 0.55F;
    }

    @Override public ResourceLocation getTextureLocation(ShadowStalker entity) { return TEXTURE; }

    @Override protected void scale(ShadowStalker entity, com.mojang.blaze3d.vertex.PoseStack poseStack, float partialTick) {
        poseStack.scale(1.62F, 1.62F, 1.62F);
    }

    @Mod.EventBusSubscriber(modid = ShadowStalkerMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class Registration {
        @SubscribeEvent
        public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(ShadowStalkerMod.SHADOW_STALKER.get(), ShadowStalkerRenderer::new);
        }
    }
}
