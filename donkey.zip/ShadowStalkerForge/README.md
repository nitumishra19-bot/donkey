# Shadow Stalker — Forge 1.20.1

A horror entity mod for Minecraft Java Edition 1.20.1 and Forge 47.x.

## Features
- A tall, dark humanoid creature (scaled to roughly three blocks tall).
- Spawns naturally in Overworld biomes where the local light level is low.
- Targets and follows nearby players when it is not being watched.
- Stops moving when a player looks directly at it; after 40 ticks (2 seconds at 20 TPS), it vanishes.
- Uses vanilla Enderman/Warden audio, applies a brief Darkness effect when first noticed, and deals heavy melee damage.

## Build on GitHub (no local computer required)
1. Create a new GitHub repository, for example `shadow-stalker-forge`.
2. Upload the *contents* of this folder (including `.github`, `src`, `build.gradle`, `settings.gradle`, and `gradle.properties`) to the repository root.
3. Open **Actions** and enable workflows if GitHub asks.
4. Select **Build Shadow Stalker Mod** and press **Run workflow**, or commit a change to `main`/`master`.
5. Open the completed green workflow run. Under **Artifacts**, download `Shadow-Stalker-Forge-1.20.1` and extract the ZIP.
6. Put `shadowstalker-1.0.0.jar` into your Minecraft `mods` folder. Install Minecraft Java 1.20.1 with Forge 47.x first.

## In-game testing
Use `/summon shadowstalker:shadow_stalker` to summon it. For a fair test, try a survival world and keep some distance. It has 60 health and deals 12 damage per hit before difficulty/armor modifiers.

## Important notes
- The entity uses vanilla Minecraft sounds, so no external sound files are required.
- This starter project includes a procedural humanoid model with a custom texture. The source ZIP is prepared, but a successful Forge compilation has not yet been confirmed. Treat the GitHub Actions run as the compile check. If the build fails, open the failed run and share the first compiler error so the source can be corrected.
